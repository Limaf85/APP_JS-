
//@Limaf 06/04/2017

// Module dependencies


var express = require('express');
var app = express();

var helmet = require('helmet');
var mysql      = require('mysql');


var connection = mysql.createConnection({

  host     : 'localhost',
  user     : 'root',
  password : '*Ctag12848680*',
  database : 'mydb'
});

// @Limaf 16/05/2017 Implementation Helmet Start Here
// Use helmet
app.use(helmet());

//Avoid XXs
//Helmet’s xssFilter will set the X-XSS-Protection header. 
//app.use(helmet(helmet.xxsFilter({setOnOldIE: true})));
var xssFilter = require('x-xss-protection')
app.use(xssFilter({ setOnOldIE: true }))


//Avoid What?
//Define the  Strict-Trnasport-Security HTTP header to tells the browsers to stick whith https and never visit the insecure HTTP
// Sets "Strict- Transport-Security: max-age=5184000; includeSubDomains"
var sixtyDaysInSeconds = 5184000
app.use(helmet.hsts({
  maxAge: sixtyDaysInSeconds //The time, in seconds, that the browser should remember that this site is only to be accessed using HTTPS.
}))


//Avoid Clickjacking
//Frameguard mitigates clickjacking attacks by setting the X-Frame-Options header. Tells browsers to prevent your webpage from being put in an iframe. 
app.use(helmet.frameguard({ action: 'deny' })) //Note: If we want use an iframe in our webpage we have to change the action to SAMEORIGINor ALL-FROM "Some Doamin".

// Hide the Powered-by
app.use(helmet.hidePoweredBy({ setTo: 'PHP 4.2.0' })) //we can lie about the technologie that we use, for example PHP instead EXPRESS or NODE 
//Note: Simply omitting this header doesn’t mean that nobody can exploit vulnerabilities!!!

//Don't Sniff Mimetype
// helps prevent browsers from trying to guess the MIME type
// Sets "X-Content-Type-Options: nosniff".
app.use(helmet.noSniff())

// @Limaf 16/05/2017 Implementation Helmet Ends Here


// Implement  
//Define the static folder paths so that it gets resovled in the node applcation
app.use('/node_modules',  express.static(__dirname + '/node_modules'));

app.use('/style',  express.static(__dirname + '/style'));

//Default route for the application
app.get('/',function(req,res){
    res.sendFile('home.html',{'root': __dirname + '/templates'});
})

//Default route to the sign page
app.get('/showSignInPage',function(req,res){
    res.sendFile('signin.html',{'root': __dirname + '/templates'});
})

app.get('/showSignUpPage',function(req,res){
  res.sendFile('signup.html',{'root':__dirname + '/templates'})
})


// Binding express app to port 3000
app.listen(3000,function(){
    console.log('Node server running @ http://localhost:3000')
});
//@Limaf Ends here



